﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FlashFindWinDemo.AssistUtils
{
    public class tools
    {

        /// <summary>
        /// 获取毫秒级时间
        /// </summary>
        /// <returns></returns>
        public static string getDateTime()
        {
            string time = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss.fff");
            //time = time.Replace("-", "").Replace(" ", "").Replace(":", "");
            return time;
        }

        /// <summary>
        /// 字符串转16进制字节数组
        /// </summary>
        /// <param name="hexString"></param>
        /// <returns></returns>
        public static byte[] HexStrToBytes(string hexString)
        {
            hexString = hexString.Replace(" ", "");
            if ((hexString.Length % 2) != 0)
                hexString += " ";
            byte[] returnBytes = new byte[hexString.Length / 2];
            for (int i = 0; i < returnBytes.Length; i++)
                returnBytes[i] = Convert.ToByte(hexString.Substring(i * 2, 2), 16);
            return returnBytes;
        }


        /// <summary>
        /// 获取发声动作
        /// </summary>
        /// <param name="beepValue"></param>
        /// <returns></returns>
        public static string getBeepString(string beepValue)
        {
            string beepString = "无声";
            switch (beepValue)
            {
                case "0":
                    beepString = "无声";
                    break;
                case "1":
                    beepString = "有声";
                    break;     
            }
            return beepString;
        }


        /// <summary>
        /// 获取闪灯动作
        /// </summary>
        /// <param name="flashValue"></param>
        /// <returns></returns>
        public static string getFlashString(string flashValue)
        {
            string flashString = "闪灯";
            switch (flashValue)
            {
                case "0":
                    flashString = "闪灯";
                    break;
                case "1":
                    flashString = "长亮";
                    break;
            }
            return flashString;
        }

        /// <summary>
        /// 获取单色or多色
        /// </summary>
        /// <param name="colorsState"></param>
        /// <returns></returns>
        public static string getColorsStateString(string colorsState)
        {
            string colorsStateString = "单色";
            switch (colorsState)
            {
                case "0":
                    colorsStateString = "单色";
                    break;
                case "1":
                    colorsStateString = "多色";
                    break;
            }
            return colorsStateString;
        }

        /// <summary>
        /// 获取按键状态
        /// </summary>
        /// <param name="keyState"></param>
        /// <returns></returns>
        public static string getKeyStateString(string keyState)
        {
            string keyStateString = "空闲时按键";
            switch (keyState)
            {
                case "1":
                    keyStateString = "空闲时按键";
                    break;
                case "2":
                    keyStateString = "动作时按键";
                    break;
            }
            return keyStateString;
        }

        /// <summary>
        /// 获取颜色动作
        /// </summary>
        /// <param name="colorValue"></param>
        /// <returns></returns>
        public static string getColorString(string colorValue)
        {
            string colorString = "";

            string[] colorNames = new string[]
            {
            "蓝",    // 第1位（低位）
            "绿",    // 第2位
            "青",    // 第3位
            "红",    // 第4位
            "紫",    // 第5位
            "黄",    // 第6位
            "白",    // 第7位
            "不亮灯" // 第8位（高位）
            };

            for (int bit = 0; bit < 8; bit++)
            {
                string currentBit = colorValue.Substring(bit, 1);
                if (currentBit == "1")
                {
                    int colorIndex = 7 - bit;
                    colorString += colorNames[colorIndex] + ",";
                }
            }

            return colorString.Substring(0, colorString.Length - 1);
        }


    }
}
