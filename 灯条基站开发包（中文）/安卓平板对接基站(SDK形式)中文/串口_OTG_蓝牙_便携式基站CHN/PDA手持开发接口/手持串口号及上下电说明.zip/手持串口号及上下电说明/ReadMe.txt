UHFDevice mUHFDevice;
mUHFDevice = new UHFDevice(this);

mUHFDevice.UhfOpen(); //上电

mUHFDevice.UhfStop();//下电

mUHFDevice.SerialDev(); //返回串口